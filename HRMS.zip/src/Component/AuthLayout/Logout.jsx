import React from 'react'

const Logout = () => {
  return (
    <div>
      logout
    </div>
  )
}

export default Logout
