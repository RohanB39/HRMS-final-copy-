import React from 'react'
import AttendanceCalendar from './AttendanceCalendar'

const AttendanceInfo = () => {
  return (
    <div>
      <AttendanceCalendar />
    </div>
  )
}

export default AttendanceInfo